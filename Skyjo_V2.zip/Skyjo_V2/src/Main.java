import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        //start the game
        Game game = new Game();
        game.start();
        while (!game.isclicked) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        game.isclicked = false;
        game.menu();
        while (!game.isclicked) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        game.isclicked = false;
        game.show_board();
        while (!game.isclicked) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        game.isclicked = false;
        game.refresh();


    }
}